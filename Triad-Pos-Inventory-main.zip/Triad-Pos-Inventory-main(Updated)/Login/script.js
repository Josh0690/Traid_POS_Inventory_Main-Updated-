document.addEventListener("DOMContentLoaded", () => {
    const overlay = document.getElementById("overlay");
    const roleBox = document.getElementById("roleBox");
    const loginBox = document.getElementById("loginBox");
    const roleTitle = document.getElementById("roleTitle");
    const loginBtn = document.getElementById("loginBtn");

    const togglePassword = document.getElementById("togglePassword");
    const passwordInput = document.getElementById("password");
    const emailInput = document.getElementById("emailInput");
    const signInBtn = document.getElementById("signInBtn");

    const backBtn = document.getElementById("backBtn");
    const eyeBtn = document.getElementById("eyeBtn");

    const passwordLabels = document.querySelectorAll(".auth-label");
    const passwordLabel = passwordLabels[1];

    let selectedRole = null;

    function showNotification(msg) {
        let toast = document.getElementById("loginToast");
        if (!toast) {
            toast = document.createElement("div");
            toast.id = "loginToast";
            Object.assign(toast.style, {
                position: "fixed",
                top: "20px",
                left: "50%",
                transform: "translateX(-50%)",
                backgroundColor: "#e53e3e",
                color: "#fff",
                padding: "10px 20px",
                borderRadius: "8px",
                boxShadow: "0 4px 12px rgba(0,0,0,0.2)",
                zIndex: "10000",
                fontSize: "14px",
                fontWeight: "600",
                opacity: "0",
                transition: "opacity 0.3s",
                pointerEvents: "none"
            });
            document.body.appendChild(toast);
        }
        toast.textContent = msg;
        requestAnimationFrame(() => { toast.style.opacity = "1"; });
        clearTimeout(toast._timer);
        toast._timer = setTimeout(() => { toast.style.opacity = "0"; }, 3000);
    }

    function applyRoleMode() {
        if (selectedRole === "Staff") {
            roleTitle.innerHTML = `Login as: <b>${selectedRole}</b>`;
            passwordLabel.textContent = "Staff PIN";
            passwordInput.placeholder = "Enter 4-digit PIN";
            passwordInput.maxLength = 4;
            passwordInput.setAttribute("inputmode", "numeric");
            passwordInput.setAttribute("pattern", "[0-9]{4}");
            passwordInput.value = "";
        } else if (selectedRole === "Owner") {
            roleTitle.innerHTML = `Login as: <b>${selectedRole}</b>`;
            passwordLabel.textContent = "Password";
            passwordInput.placeholder = "Enter Password";
            passwordInput.removeAttribute("maxlength");
            passwordInput.removeAttribute("inputmode");
            passwordInput.removeAttribute("pattern");
            passwordInput.value = "";
        }
    }

    loginBtn.addEventListener("click", () => {
        overlay.style.display = "flex";
        roleBox.style.display = "block";
        loginBox.style.display = "none";
    });

    document.querySelectorAll("[data-role]").forEach(button => {
        button.addEventListener("click", () => {
            selectedRole = button.dataset.role;
            roleBox.style.display = "none";
            loginBox.style.display = "grid";
            applyRoleMode();
        });
    });

    backBtn.addEventListener("click", () => {
        loginBox.style.display = "none";
        roleBox.style.display = "block";
        passwordInput.value = "";
        togglePassword.checked = false;
        passwordInput.type = "password";
        emailInput.style.borderColor = "";
        passwordInput.style.borderColor = "";
    });

    passwordInput.addEventListener("input", () => {
        passwordInput.style.borderColor = "";
        if (selectedRole === "Staff") {
            passwordInput.value = passwordInput.value.replace(/\D/g, "").slice(0, 4);
        }
    });

    emailInput.addEventListener("input", () => {
        emailInput.style.borderColor = "";
    });

    togglePassword.addEventListener("change", () => {
        passwordInput.type = togglePassword.checked ? "text" : "password";
    });

    eyeBtn.addEventListener("click", () => {
        const nowText = passwordInput.type === "password";
        passwordInput.type = nowText ? "text" : "password";
        togglePassword.checked = nowText;
    });

    signInBtn.addEventListener("click", () => {
        const enteredValue = passwordInput.value.trim();
        const emailValue = emailInput.value.trim();

        // Reset borders
        emailInput.style.borderColor = "";
        passwordInput.style.borderColor = "";

        if (emailValue === "") {
            emailInput.style.borderColor = "red";
        }
        if (enteredValue === "") {
            passwordInput.style.borderColor = "red";
        }

        if (emailValue === "" || enteredValue === "") {
            showNotification("Please Enter Email or Password");
            return;
        }

        if (selectedRole === "Staff") {
            if (!/^\d{4}$/.test(enteredValue)) {
                showNotification("Staff PIN must be exactly 4 digits.");
                return;
            }

            window.location.href = "../Staff/staff.html";
        } else if (selectedRole === "Owner") {
            if (enteredValue === "") {
                showNotification("Please enter password.");
                return;
            }

            window.location.href = "../owner/owner.html";
        } else {
            showNotification("Please select a role first.");
        }
    });

    overlay.addEventListener("click", (e) => {
        if (e.target === overlay) {
            overlay.style.display = "none";
        }
    });
});